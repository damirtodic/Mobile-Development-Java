package com.example.damirtodic;

import androidx.room.Entity;
import androidx.room.Ignore;
import androidx.room.PrimaryKey;

@Entity(tableName = "mobiles")
public class Mobile {

    @PrimaryKey(autoGenerate = true)
    private long id;
    private String model;
    private String color;
    private String price;
    private String memory;
    private String camera_pixels;
    private String year_of_manufacturing;


    @Ignore
    public Mobile(String model, String color, String price, String memory, String camera_pixels, String year_of_manufacturing) {
        this.model = model;
        this.color = color;
        this.price = price;
        this.memory = memory;
        this.camera_pixels = camera_pixels;
        this.year_of_manufacturing = year_of_manufacturing;
    }

    public Mobile(long id, String model, String color, String price, String memory, String camera_pixels, String year_of_manufacturing) {
        this.id = id;
        this.model = model;
        this.color = color;
        this.price = price;
        this.memory = memory;
        this.camera_pixels = camera_pixels;
        this.year_of_manufacturing = year_of_manufacturing;
    }

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public String getModel() {
        return model;
    }

    public void setModel(String model) {
        this.model = model;
    }

    public String getColor() {
        return color;
    }

    public void setColor(String color) {
        this.color = color;
    }

    public String getPrice() {
        return price;
    }

    public void setPrice(String price) {
        this.price = price;
    }

    public String getMemory() {
        return memory;
    }

    public void setMemory(String memory) {
        this.memory = memory;
    }

    public String getCamera_pixels() {
        return camera_pixels;
    }

    public void setCamera_pixels(String camera_pixels) {
        this.camera_pixels = camera_pixels;
    }

    public String getYear_of_manufacturing() {
        return year_of_manufacturing;
    }

    public void setYear_of_manufacturing(String year_of_manufacturing) {
        this.year_of_manufacturing = year_of_manufacturing;
    }
}



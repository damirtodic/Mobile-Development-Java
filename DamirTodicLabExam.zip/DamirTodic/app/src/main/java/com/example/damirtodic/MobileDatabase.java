package com.example.damirtodic;

import android.content.Context;

import androidx.room.Database;
import androidx.room.Room;
import androidx.room.RoomDatabase;

@Database(entities={Mobile.class},version=1,exportSchema = false)
public abstract class MobileDatabase extends RoomDatabase {

    public abstract MobileDao mobileDao();

    public static MobileDatabase INSTANCE = null;

    public static MobileDatabase getInstance(Context context){
        if(INSTANCE == null){
            INSTANCE = Room.databaseBuilder(context, MobileDatabase.class, "mobiles-database").allowMainThreadQueries().build();
        }
        return INSTANCE;
    }
}
package com.example.damirtodic;

import androidx.room.Dao;
import androidx.room.Delete;
import androidx.room.Insert;
import androidx.room.Query;

import java.util.List;

@Dao
public interface MobileDao {

    @Insert
    public void addMobile(Mobile mobile);

    @Query("SELECT * FROM mobiles")
    List<Mobile> getAll();

    @Query("SELECT * FROM mobiles WHERE id=(:id)")
    Mobile getMobile(long id);

    @Delete
    public void deleteMobile(Mobile mobile);


}

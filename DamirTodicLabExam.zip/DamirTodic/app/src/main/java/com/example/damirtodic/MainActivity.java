package com.example.damirtodic;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;

import java.util.List;

public class MainActivity extends AppCompatActivity {

    ListView listview;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        listview=findViewById(R.id.listview);
        List<Mobile> mobiles = MobileDatabase.getInstance(this).mobileDao().getAll();
        Adapter adapter = new Adapter(this, mobiles);
        listview.setAdapter(adapter);

        listview.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                Mobile mobile=(Mobile) adapterView.getItemAtPosition(i);
                String model = mobile.getModel();
                String color= mobile.getColor();
                String price = mobile.getPrice();
                String memory=mobile.getMemory();
                String pixels=mobile.getCamera_pixels();
                String year=mobile.getYear_of_manufacturing();
                long id = mobile.getId();
                Intent intent = new Intent(getApplicationContext(), Details.class);
                intent.putExtra("model", model);
                intent.putExtra("color", color);
                intent.putExtra("price", price);
                intent.putExtra("memory", memory);
                intent.putExtra("pixels", pixels);
                intent.putExtra("year", year);
                intent.putExtra("id",mobile.getId());
                startActivity(intent);
            }
        });
    }

    public void addCar(View view){
        Intent intent = new Intent(this,Details.class);
        startActivity(intent);
    }

}
package com.example.damirtodic;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import java.util.List;

public class Adapter extends BaseAdapter {

    private List<Mobile> mobileList;
    private Context context;

    public Adapter(Context context, List<Mobile> mobileList){
        this.context = context;
        this.mobileList = mobileList;
    }

    @Override
    public int getCount() {
        return mobileList.size();
    }

    @Override
    public Object getItem(int i) {
        return mobileList.get(i);
    }

    @Override
    public long getItemId(int i) {
        return mobileList.indexOf(mobileList.get(i));
    }

    @Override
    public View getView(int i, View view, ViewGroup viewGroup) {
        LayoutInflater inflater = LayoutInflater.from(context);
        view = inflater.inflate(R.layout.listview_layout, viewGroup, false);
        Mobile mobile = (Mobile) getItem(i);
        TextView model = view.findViewById(R.id.model);
        TextView color=view.findViewById(R.id.color);
        TextView price = view.findViewById(R.id.price);
        TextView memory = view.findViewById(R.id.memory);

        model.setText(mobile.getModel());
        color.setText(mobile.getColor());
        price.setText(mobile.getPrice());
        memory.setText(mobile.getMemory());

        return view;
    }
}

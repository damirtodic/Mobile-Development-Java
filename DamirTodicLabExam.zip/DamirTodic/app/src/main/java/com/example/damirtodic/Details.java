package com.example.damirtodic;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;

public class Details extends AppCompatActivity {

    EditText model,color,price,memory,camera_pixels,year_of_manufacturing;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_details);
        model=findViewById(R.id.model);
        color=findViewById(R.id.color);
        price=findViewById(R.id.price);
        memory=findViewById(R.id.memory);
        camera_pixels=findViewById(R.id.camera_pixels);
        year_of_manufacturing=findViewById(R.id.year_of_manufacturing);

        String getModel= getIntent().getStringExtra("model");
        model.setText(getModel);
        String getColor= getIntent().getStringExtra("color");
        color.setText(getColor);
        String getPrice= getIntent().getStringExtra("price");
        price.setText(getPrice);
        String getMemory= getIntent().getStringExtra("memory");
        memory.setText(getMemory);
        String getPixels= getIntent().getStringExtra("camera_pixels");
        camera_pixels.setText(getPixels);
        String getYear_of_manufacturing= getIntent().getStringExtra("year_of_manufacturing");
        year_of_manufacturing.setText(getYear_of_manufacturing);

        long id=getIntent().getLongExtra("id",0);
    }


    public void delete(View view)
    {
        long id = getIntent().getLongExtra("id", 0);
        Mobile mobile = MobileDatabase.getInstance(this).mobileDao().getMobile(id);
        MobileDatabase.getInstance(this).mobileDao().deleteMobile(mobile);
        Intent intent=new Intent(this,MainActivity.class);
        startActivity(intent);
    }

    public void add(View view)
    {

        Mobile mobile=new Mobile(model.getText().toString(),color.getText().toString(),price.getText().toString(),memory.getText().toString(),
                camera_pixels.getText().toString(),year_of_manufacturing.getText().toString());
        MobileDatabase.getInstance(this).mobileDao().addMobile(mobile);

        Intent intent=new Intent(this,MainActivity.class);
        startActivity(intent);
    }



}